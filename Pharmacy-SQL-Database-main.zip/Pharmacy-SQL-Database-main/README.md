# Pharmacy-SQL- Database

SQL database designed for pharmacies

Problem Definition: It helps the pharmacists to be able to control the drug traffic. The system records the pharmacy inventory‘s operations, the drugs that are sold and the drugs that are new in. The system saves the payment details and also it records the doctor, patient and employee information. As mentioned in part 3, users will be pharmacists and pharmacist assistants. The main assumption is there are a lot of drug types and a lot of pharmacies which needs this system because there lots of patients too. We assume that a pharmacy has lots of employees and one pharmacy takes drugs from one inventory. Our assumption is that a pharmacy has lots of sales in a day and the pharmacy needs a database system to keep track of all the payments. Each payment consists of one type of drug. Each pharmacy has one inventory.
